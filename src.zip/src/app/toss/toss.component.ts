import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'toss',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './toss.component.html',
  styleUrl: './toss.component.css'
})
export class TossComponent {  
  choice = ''
  optionSelected = false
}
